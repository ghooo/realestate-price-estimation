Order of information in the annotations:
(number of bedrooms) (number of bathrooms) (aprox. area in sqft) (zip code) (price in $)